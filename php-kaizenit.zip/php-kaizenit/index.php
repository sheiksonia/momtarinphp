<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>php practic</title>
	<link rel="stylesheet" href="">
</head>
<body>
	<?php

	$no = 20;

	echo "$no X 1 = ".($no*1). "<br>";
	echo "$no X 2 = ".($no*2). "<br>";
	echo "$no X 3 = ".($no*3). "<br>";
	echo "$no X 4 = ".($no*4). "<br>";
	echo "$no X 5 = ".($no*5). "<br>";
	echo "$no X 6 = ".($no*6). "<br>";
	echo "$no X 7 = ".($no*7). "<br>";
	echo "$no X 8 = ".($no*8). "<br>";
	echo "$no X 9 = ".($no*9). "<br>";
	echo "$no X 10 = ".($no*10). "<br>";
	echo "$no X 11 = ".($no*11). "<br> <br> <br> <br> <br> <br>";

	 /*this is php watch*/

	 $time = 600;

	 $h = $time/60;
	 $m = $time%60;

	 echo floor($h).' hr : '.$m.' min';







	?>
	
</body>
</html>